#include "kik.hpp"

int Kik::objectNumber_ = 0;
int Kik::errorNumber_ = 0;

Kik::Kik(Marker player1, Marker player2) : player1_(player1), player2_(player2) {
    objectNumber_++;
    board_ = Board();
}

Kik::Kik(const Kik &other) {
    objectNumber_++;
    board_ = Board(other.board_);
    player1_ = Marker(other.player1_);
    player2_ = Marker(other.player2_);
    isPlayer1_ = other.isPlayer1_;
}

Kik &Kik::operator=(const Kik &other) {
    if (this == &other)
        return *this;

    board_ = Board(other.board_);
    player1_ = Marker(other.player1_);
    player2_ = Marker(other.player2_);
    isPlayer1_ = other.isPlayer1_;

    return *this;
}

bool Kik::playAt(int row, int col, Marker player) {
    if (row < 0 || row > 2 || col < 0 || col > 2
        || (isPlayer1_ && player.getValue() != player1_.getValue())
        || (!isPlayer1_ && player.getValue() != player2_.getValue())
        || (!board_.get(row, col).isEmpty())) {
        myErrorNumber_++;
        errorNumber_++;
        return false;
    }

    board_.set(row, col, player);
    isPlayer1_ ^= 1;
    return true;
}

const Marker *Kik::getWinner() const {
    for (int i = 0; i < 3; ++i) {
        Marker a = board_.get(i, 0), b = board_.get(i, 1), c = board_.get(i, 2);
        if (!a.isEmpty() && a.getValue() == b.getValue() && b.getValue() == c.getValue())
            return board_.getRef(i, 0);

        a = board_.get(0, i), b = board_.get(1, i), c = board_.get(2, i);
        if (!a.isEmpty() && a.getValue() == b.getValue() && b.getValue() == c.getValue())
            return board_.getRef(0, i);
    }

    Marker a = board_.get(0, 0), b = board_.get(1, 1), c = board_.get(2, 2);
    if (!a.isEmpty() && a.getValue() == b.getValue() && b.getValue() == c.getValue())
        return board_.getRef(0, 0);

    a = board_.get(0, 2), b = board_.get(1, 1), c = board_.get(2, 0);
    if (!a.isEmpty() && a.getValue() == b.getValue() && b.getValue() == c.getValue())
        return board_.getRef(0, 2);

    return nullptr;
}

std::ostream &operator<<(std::ostream &os, const Kik &kik) {
    os << kik.board_;
    return os;
}

int Kik::objectNumber() {
    return objectNumber_;
}

int Kik::errorNumber() {
    return errorNumber_;
}

Kik::~Kik() {
    objectNumber_--;
    errorNumber_ -= myErrorNumber_;
}