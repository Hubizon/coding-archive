#ifndef TICTACTOE_MARKER_HPP
#define TICTACTOE_MARKER_HPP

/**
 * Represents a Marker which is put in the empty cell whenever a player makes a move.
 * Usually it is X or O, but this class allows for customization.
 */
class Marker {
  char value_;
 public:
  Marker() : Marker(Marker::EMPTY) {} // constructs the empty marker
  Marker(char value);                 // constructs a marker of given character

  char getValue() const;
  bool isEmpty() const;  // returns true iff this marker is the empty marker

  static Marker EMPTY;
};

#endif //TICTACTOE_MARKER_HPP
