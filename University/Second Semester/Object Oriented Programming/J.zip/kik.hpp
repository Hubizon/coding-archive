#ifndef TICTACTOE_KIK_HPP
#define TICTACTOE_KIK_HPP

#include <iostream>
#include "board.hpp"
#include "marker.hpp"

/**
 * Represents a TicTacToe game.
 */
class Kik {
  Board board_;
  Marker player1_;
  Marker player2_;
  bool isPlayer1_ = true;
  int myErrorNumber_ = 0;
  static int objectNumber_;
  static int errorNumber_;
 public:
  /**
   * Initializes the game with an empty board and 2 players identified by the given markers;
   * $player1 goes first.
   */
  Kik(Marker player1, Marker player2);
  Kik(const Kik &);             // copies the game state from the argument
  Kik &operator=(const Kik &);  // copies the game state from the argument

  /**
   * Attempts to make a move by $player in cell ($row, $col);
   * fails if the move is not valid.
   * @return true if the move was performed successfully, false otherwise
   */
  bool playAt(int row, int col, Marker player);
  const Marker *getWinner() const; // returns the winner of the game (if there is one), or nullptr otherwise

  friend std::ostream &operator<<(std::ostream &, const Kik &); // prints the board

  static int objectNumber(); // returns the number of existing Kik objects
  static int errorNumber();  // returns the number of unsuccessful playAt() calls among the existing Kik objects so fars

  ~Kik();
};

#endif //TICTACTOE_KIK_HPP
