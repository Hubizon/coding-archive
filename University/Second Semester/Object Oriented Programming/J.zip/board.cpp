#include "board.hpp"
#include <iostream>

Board::Board() {
}

Board::Board(Marker m[3][3]) {
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            this->board_[i][j] = m[i][j];
}

Board::Board(const Board &other) {
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            this->board_[i][j] = other.board_[i][j];
}

Board &Board::operator=(const Board &other) {
    if (this == &other)
        return *this;

    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            this->board_[i][j] = other.board_[i][j];

    return *this;
}

void Board::set(int row, int col, Marker m) {
    this->board_[row][col] = m;
}

Marker Board::get(int row, int col) const {
    return board_[row][col];
}

const Marker *Board::getRef(int row, int col) const {
    return &board_[row][col];
}

std::ostream &operator<<(std::ostream &os, const Board &board) {
    board.printNumber_++;
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++)
            os << board.board_[i][j].getValue() << ' ';
        os << '\n';
    }
    return os;
}

int Board::printNumber() const {
    return printNumber_;
}