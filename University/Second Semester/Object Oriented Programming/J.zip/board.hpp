#ifndef TICTACTOE_BOARD_HPP
#define TICTACTOE_BOARD_HPP

#include <iostream>
#include <array>
#include "marker.hpp"

/**
 * Represents a 3x3 board for TicTacToe.
 * Each cell of the board is a Marker object.
 * An empty (unfilled) cell is represented by Marker::EMPTY.
 */
class Board {
  Marker board_[3][3] = {};
  mutable int printNumber_ = 0;
 public:
  Board();                        // constructs an empty board
  Board(Marker[3][3]);            // constructs a board filled with given markers
  Board(const Board &);            // constructs a board filled with given markers
  Board &operator=(const Board &); // copies the markers from the argument board

  void set(int row, int col, Marker m);
  Marker get(int row, int col) const;
  const Marker *getRef(int row, int col) const;

  friend std::ostream &operator<<(std::ostream &, const Board &); // prints the board
  int printNumber() const; // returns the number of times this Board object has been printed so far
};

#endif //TICTACTOE_BOARD_HPP
