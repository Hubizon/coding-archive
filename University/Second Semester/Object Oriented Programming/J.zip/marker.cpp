#include "marker.hpp"

Marker Marker::EMPTY('.');

Marker::Marker(char value) : value_(value) {
}

char Marker::getValue() const {
    return value_;
}

bool Marker::isEmpty() const {
    return value_ == EMPTY.getValue();
}
