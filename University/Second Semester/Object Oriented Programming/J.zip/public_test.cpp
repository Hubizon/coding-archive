#include <iostream>
#include "kik.cpp"

using namespace std;

#define PRINT(x) cout << x << endl

int main(int argc, char *argv[]) {
    Kik g('X', 'O');
    PRINT(g.playAt(0, 0, 'X'));
    PRINT(g.playAt(1, 0, 'O'));
    PRINT(g.playAt(0, 1, 'X'));
    PRINT(g.playAt(1, 1, 'O'));
    PRINT(g.playAt(0, 2, 'X'));
    PRINT(g.playAt(2, 2, 'O'));
    PRINT(g.playAt(1, 2, 'X'));
    /*
        X X X
        O O X
        . . O
    */
    const Kik k1(g);
    Kik k2('A', 'B');
    k2 = k1;
    PRINT(k2.playAt(0, 1, 'O'));
    PRINT(k2.playAt(2, 1, 'O'));
    cout << k1 << endl;
    cout << k2 << endl;
    cout << Kik::errorNumber() << endl;
    cout << Kik::objectNumber() << endl;
    return 0;
}
