#include "solution.h"
#include <algorithm>
#include <vector>

A::Proxy::Proxy(A* p) : p(p), a(*p) { }

int A::Proxy::operator()() & {
    int val = a.arr->back();
    a.arr->pop_back();
    return val;
}

int A::Proxy::operator()() && {
    int val = a.arr->back();
    a.arr->pop_back();
    return val + 1729;
}

int A::Proxy::operator()() const & {
    return 44;
}

A& A::Proxy::operator()(const int&& val) & {
    a.arr->push_back(val);
    return a;
}

A& A::Proxy::operator()(int& val) & {
    a.arr->push_front(val);
    return a;
}

A& A::Proxy::operator()(const int& val) & {
    if (a.arr->size() % 2 == 0)
        a.arr->push_back(val);
    else
        a.arr->push_front(val);
    return a;
}

A A::Proxy::operator()(const int&& val) && {
    a.arr->push_back(val);
    return std::move(*p);
}

A A::Proxy::operator()(int& val) && {
    a.arr->push_front(val);
    return std::move(*p);
}

A A::Proxy::operator()(const int& val) && {
    if (a.arr->size() % 2 == 0)
        a.arr->push_back(val);
    else
        a.arr->push_front(val);
    return std::move(*p);
}

void A::Proxy::operator()(const int&&) const & { }

std::string A::Proxy::toString(int b) const {
    std::string result = "[";
    for (auto it = a.arr->begin(); it != a.arr->end(); ++it) {
        result += std::to_string(*it + b);
        auto next = it; ++next;
        if (next != a.arr->end())
            result += ", ";
    }
    result += "]";
    return result;
}

std::ostream& operator<<(std::ostream& os, const A::Proxy& p) {
    os << p.toString();
    return os;
}

std::ostream& operator<<(std::ostream& os, A::Proxy&& p) {
    os << p.toString(1729);
    return os;
}

A::A() : sorted(true), arr(new std::list<int>()), a(this) { }

A::A(const A& other) : sorted(other.sorted), arr(new std::list<int>(*other.arr)), a(this) { }

A::A(A&& other) : sorted(other.sorted), arr(other.arr), a(this) {
    other.arr = new std::list<int>;
}

A::~A() {
    delete arr;
    arr = nullptr;
}

int A::operator()() {
    auto& L = *arr;
    if (L.empty()) return 0;
    int x = L.back();
    L.pop_back();
    return x;
}

int A::operator()() const {
    return 44;
}

A& A::operator()(const int&& val) {
    arr->push_back(val);
    return *this;
}

A& A::operator()(int& val) & {
    arr->push_front(val);
    return *this;
}

A& A::operator()(const int& val) & {
    if (arr->size() % 2 == 0)
        arr->push_back(val);
    else
        arr->push_front(val);
    return *this;
}

void A::operator()(const int&&) const { }

std::string A::toString() const {
    std::vector<int> sorted_arr(arr->begin(), arr->end());
    std::sort(sorted_arr.begin(), sorted_arr.end());
    std::string result = "[";
    for (size_t i = 0; i < sorted_arr.size(); ++i) {
        result += std::to_string(sorted_arr[i]);
        if (i + 1 < sorted_arr.size())
            result += ", ";
    }
    result += "]";
    return result;
}

std::ostream& operator<<(std::ostream& os, const A& a) {
    os << a.toString();
    return os;
}
