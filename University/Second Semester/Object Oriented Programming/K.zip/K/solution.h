// Hubert Jastrzębski | Satori K (Powrót Świra Cpp) | 2025-06-01
// https://satori.tcs.uj.edu.pl/contest/9753924/problems/10059569

#ifndef A_H
#define A_H

#include <ostream>
#include <string>
#include <list>

class A {
 public:
  bool sorted;
  std::list<int> *arr = nullptr;

  class Proxy {
    A* p;
   public:
    A& a;
    Proxy(A* p);

    int operator()() &;
    int operator()() &&;
    int operator()() const &;
    A& operator()(const int &&val) &;
    A& operator()(int& val) &;
    A& operator()(const int& val) &;
    A operator()(const int &&val) &&;
    A operator()(int& val) &&;
    A operator()(const int& val) &&;
    void operator()(const int &&val) const &;

    std::string toString(int b = 0) const;

    friend std::ostream& operator<<(std::ostream& os, const Proxy& p);
    friend std::ostream& operator<<(std::ostream& os, Proxy&& p);
  };

 public:
  Proxy a;

  A();
  A(const A& other);
  A(A&& other);
  ~A();

  int operator()();
  int operator()() const;
  A& operator()(const int &&val);
  A& operator()(int& val) &;
  A& operator()(const int& val) &;
  void operator()(const int &&val) const;
  std::string toString() const;

  friend std::ostream& operator<<(std::ostream& os, const A& a);
};

#endif // A_H