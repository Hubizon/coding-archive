#ifndef PO10_SHIP_HEADER
#define PO10_SHIP_HEADER

#include <istream>
#include "galaxy.h"
#include "vector.h"

class Ship {
 protected:
  Galaxy* galaxy;
  Galaxy::Starsystem* system;
  Vector<int> path;
  int pos = -1;

 public:
  void setPath(std::istream &in);
  virtual Galaxy::Starsystem *start(Galaxy *g);
  virtual Galaxy::Starsystem *advance();
  virtual Galaxy::Starsystem *currentSystem();
  virtual ~Ship();
};

#endif

