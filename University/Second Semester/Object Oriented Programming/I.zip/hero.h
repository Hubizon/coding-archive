#ifndef PO10_HERO_HEADER
#define PO10_HERO_HEADER

#include "galaxy.h"
#include "ship.h"

class Hero : public Ship {
 public:
  Galaxy::Starsystem *advance();
};

#endif
