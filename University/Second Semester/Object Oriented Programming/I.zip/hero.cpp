#include "hero.h"

Galaxy::Starsystem *Hero::advance() {
    if (pos >= path.size() - 1)
        return nullptr;
    return Ship::advance();
}