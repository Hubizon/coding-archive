#include "reaper.h"

Galaxy::Starsystem *Reaper::start(Galaxy *g) {
    Ship::start(g);
    system->setCorrupted();
    return system;
}

Galaxy::Starsystem *Reaper::advance() {
    Ship::advance();
    if (this->system != nullptr)
        system->setCorrupted();
    return system;
}