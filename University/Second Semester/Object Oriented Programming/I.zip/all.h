/**
 * PO 2024/25, Problem I - Kosmiczna ucieczka
 * 2025-05-16 : https://satori.tcs.uj.edu.pl/contest/9753924/problems/10000752
 * @author Hubert Jastrzębski
 */

#ifndef PO10_ALL_HEADER
#define PO10_ALL_HEADER

#include "result.h"
#include "galaxy.h"
#include "output.h"
#include "vector.h"
#include "hero.h"
#include "reaper.h"
#include "ship.h"

//Hero and Reaper classes need to be defined somewhere and their definitions must be included here
//Also include any other files that should be visible in order to use your classes

#endif

