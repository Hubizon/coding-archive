#include <iostream>
#include "result.h"

void print_result(Result r) {
    switch (r) {
        case Result::Invalid:
            std::cout << "Invalid\n";
            break;
        case Result::Success:
            std::cout << "Success\n";
            break;
        case Result::Failure:
            std::cout << "Failure\n";
            break;
    }
}