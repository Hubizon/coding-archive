#include "galaxy.h"
#include "hero.h"
#include "reaper.h"

Galaxy &Galaxy::load(std::istream &in) {
    int N, T;
    in >> N >> T;
    for (int i = 0; i < N; i++) {
        Starsystem system;
        systems.push_back(system);
    }
    for (int i = 0; i < N; i++)
        systems[i].load(this, in);

    systems[T].setTarget();
    return *this;
}

Galaxy &Galaxy::add(Reaper *r) {
    reapers.push_back(r);
    return *this;
}

Galaxy &Galaxy::add(Hero *h) {
    if (hero != nullptr)
        delete hero;
    hero = h;
    return *this;
}

Result Galaxy::simulate() {
    hero->start(this);
    for (int i = 0; i < reapers.size(); i++)
        reapers[i]->start(this);

    if (hero->currentSystem()->isTarget())
        return Result::Success;
    if (hero->currentSystem()->isCorrupted())
        return Result::Failure;

    while (true) {
        if (hero->advance() == nullptr)
            return Result::Invalid;
        for (int i = 0; i < reapers.size(); i++)
            if (reapers[i]->advance() == nullptr)
                return Result::Invalid;

        if (hero->currentSystem()->isTarget())
            return Result::Success;
        if (hero->currentSystem()->isCorrupted())
            return Result::Failure;
    }
}

size_t Galaxy::systemsCnt() {
    return systems.size();
}

Galaxy::Starsystem *Galaxy::getSystem(size_t idx) {
    return &systems[idx];
}

Galaxy::~Galaxy() {
    delete hero;
    for (int i = 0; i < reapers.size(); i++)
        delete reapers[i];
}

Galaxy::Starsystem &Galaxy::Starsystem::load(Galaxy *g, std::istream &in) {
    galaxy = g;

    int E;
    in >> E;
    for (int i = 0; i < E; i++) {
        size_t idx;
        in >> idx;
        adj.push_back(g->getSystem(idx));
    }
    return *this;
}

Galaxy::Starsystem *Galaxy::Starsystem::adjacent(size_t idx) {
    return adj[idx];
}

bool Galaxy::Starsystem::isTarget() {
    return target;
}

void Galaxy::Starsystem::setTarget() {
    target = true;
}

bool Galaxy::Starsystem::isCorrupted() {
    return corrupted;
}

void Galaxy::Starsystem::setCorrupted() {
    corrupted = true;
}

size_t Galaxy::Starsystem::adjacentSize() {
    return adj.size();
}
