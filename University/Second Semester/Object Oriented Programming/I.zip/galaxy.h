#ifndef PO10_GALAXY_HEADER
#define PO10_GALAXY_HEADER

#include <istream>
#include "result.h"
#include "vector.h"

class Hero;

class Reaper;

class Galaxy {
 public:
  class Starsystem;

 private:
  Vector<Starsystem> systems;
  Vector<Reaper*> reapers;
  Hero* hero = nullptr;

 public:
  Galaxy &load(std::istream &in);
  Galaxy &add(Reaper *r);
  Galaxy &add(Hero *h);
  Result simulate();
  size_t systemsCnt();

  class Starsystem {
   private:
    Galaxy* galaxy = nullptr;
    Vector<Starsystem*> adj;
    bool target = false;
    bool corrupted = false;

   public:
    Starsystem &load(Galaxy *g, std::istream &in);
    Starsystem *adjacent(size_t idx);
    bool isTarget();
    void setTarget();
    bool isCorrupted();
    void setCorrupted();
    size_t adjacentSize();
  };

  Starsystem *getSystem(size_t idx);

  ~Galaxy();
};

#endif

