#ifndef PO10_REAPER_HEADER
#define PO10_REAPER_HEADER

#include "galaxy.h"
#include "ship.h"

class Reaper : public Ship {
 public:
  Galaxy::Starsystem *start(Galaxy *g);
  Galaxy::Starsystem *advance();
};

#endif
