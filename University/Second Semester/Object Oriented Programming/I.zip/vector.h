#ifndef PO10_VECTOR_HEADER
#define PO10_VECTOR_HEADER

#include <istream>

template<typename T>
class Vector {
 private:
  T *data = nullptr;
  size_t capacity = 0, length = 0;
  void resize() {
      capacity = capacity == 0 ? 1 : 2 * capacity;
      T* ndata = new T[capacity];
      for (int i = 0; i < length; i++)
          ndata[i] = data[i];
      delete[] data;
      data = ndata;
  }

 public:
  ~Vector() {
      delete[] data;
  }

  void push_back(const T& value) {
      if (length == capacity)
          resize();
      data[length++] = value;
  }

  T& operator[](size_t index) {
      return data[index];
  }

  size_t size() const {
      return length;
  }
};

#endif