#include "ship.h"
#include "vector.h"

void Ship::setPath(std::istream &in) {
    int K;
    in >> K;
    for (int i = 0; i < K; i++) {
        int idx;
        in >> idx;
        path.push_back(idx);
    }
}

Galaxy::Starsystem *Ship::start(Galaxy *g) {
    galaxy = g;
    pos = 0;
    system = g->getSystem(path[0]);
    return system;
}

Galaxy::Starsystem *Ship::advance() {
    if (pos >= path.size() - 1)
        return system;

    pos++;
    if (path[pos] >= system->adjacentSize())
        return nullptr;
    system = system->adjacent(path[pos]);
    return system;
}

Galaxy::Starsystem *Ship::currentSystem() {
    return system;
}

Ship::~Ship() {

}